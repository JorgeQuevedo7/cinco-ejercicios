﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tablamultiplicarwf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out int numero))
            {
                MessageBox.Show("Por favor, ingrese un número válido.");
                return;
            }

            lblTablaMultiplicar.Text = "";

            for (int i = 1; i <= 10; i++)
            {
                int resultado = numero * i;
                lblTablaMultiplicar.Text += $"{numero} x {i} = {resultado}\n";
            }
        }
    }
}
