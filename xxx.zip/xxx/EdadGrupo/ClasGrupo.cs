﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EdadGrupo
{
    internal class ClasGrupo
    {

        public void edad(object sender, EventArgs e)
        {

            int a = 0, b = 0, c = 0;
           


            if (a < b && b < c && a < b)
                MessageBox.Show("El mayor es", +c + "El menor es" + a);
            else if (a < b && b < c && a > b)
                MessageBox.Show("El mayor es", +c + "El menor es" +b);
            if (a < b && b > c && a < c)
                MessageBox.Show("El mayor es", +b + "el menor es" +a);
            else if (a < b && b > c && a < c)
                MessageBox.Show("El mayor es", +b + "El menor es" +c);
            if (a > b && a > c && b < c)
                MessageBox.Show("El mayor es", +a + "El menor es" +b);
            if (a > b && a > c && b > c)
                MessageBox.Show("El mayor es", +a + "El menor es" +c);

        }
    }
}